'use strict';
let startServer = require('./server.js');

startServer();
