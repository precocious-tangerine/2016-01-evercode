#!/bin/bash
# function extractTokenFromJson() {
# 	token=`echo $1 | perl -nle 'print $& if m{(?:"token":")\K([^="]*)}'`
# 	echo ${token}
# }

# function extractMsgFromJson() {
# 	msg=`echo $1 | perl -nle 'print $& if m{(?:"msg":")\K([^="]*)}'`
# 	echo ${msg}
# }
echo -n ""
echo "Nevercode Setup"
echo -n ""
echo "Please copy your client secret here:"
read secret

result=`curl --header "secret: ${secret}" http://localhost:3003/user/sublime-secret`
if [ "$result" != "Unauthorized" ]
then
	echo -n ""
	echo 'Client secret is valid. Setting up sublime plugin'
	echo ${secret} > 'Nevercode/client_secret.txt'
	cp -Rf ./Nevercode /Users/$USER/Library/Application\ Support/Sublime\ Text\ 3/Packages/
	echo 'Sublime Plugin setup complete'
	echo 'You may now sync your snippets with Sublime using the button in the Preferences Menu'
else
	echo 'Invalid Credentials. Please run again'
fi
