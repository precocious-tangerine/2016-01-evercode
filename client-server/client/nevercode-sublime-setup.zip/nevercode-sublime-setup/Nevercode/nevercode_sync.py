import sublime, sublime_plugin
import sys
import os

dirName = os.path.dirname(__file__)
sys.path.append(os.path.join(dirName, 'requests-2.9.1'))
import requests

class NevercodeCommand(sublime_plugin.TextCommand, sublime_plugin.WindowCommand):
	def run(self, edit):
		totalChars = 0
		newView = self.view.window().new_file()
		totalChars += newView.insert(edit, totalChars, 'Initializing...\n')
		snippetHeader = "<snippet>\n<content>\n";
		snippetTab = "\n</content>\n<tabTrigger>NC_";
		snippetFooter = "</tabTrigger>\n</snippet>";

		secretFile = open(os.path.join(dirName,'client_secret.txt'), 'r')
		secret = str(secretFile.read()).strip('\n')
		secretFile.close()

		totalChars += newView.insert(edit, totalChars, 'Parsing Client Secret...\n')
		headers = {'Allow-Control-Allow-Origin': '*', 'secret': secret}
		tokenResp = requests.get('http://localhost:3003/user/sublime-secret', headers=headers)
		token = str(tokenResp.text).strip('\n')
		print('token is' + token);

		if(token == 'Unauthorized'):
			totalChars += newView.insert(edit, totalChars, 'Error, invalid client secret.\nPlease run setup again with new client secret');
		else:
			totalChars += newView.insert(edit, totalChars, 'Requesting Nevercode Server...\n')
			headers = {'Allow-Control-Allow-Origin': '*', 'authorization': token}
			snipResp = requests.get('http://localhost:3002/files/api/user/snippets', headers=headers)
			jsonDict = snipResp.json()

			totalChars += newView.insert(edit, totalChars, 'Response received from Nevercode server.\n')
			totalChars += newView.insert(edit, totalChars, 'User snippets received. Constructing snippets now\n')
			for key, value in jsonDict.items():
			    if(value['name'] != '.config'):
			    		totalChars += newView.insert(edit, totalChars, 'Constructing snippet ' + value['name'] + ' with trigger ' + value['name'] + '\n')
			    		snippetContent = value['data']
			    		snippetName = value['name']
			    		fullSnippetFile = snippetHeader + snippetContent + snippetTab + snippetName + snippetFooter
			    		snipRef = open(os.path.join(dirName, 'snippets', snippetName + '.sublime-snippet'), 'w+')
			    		snipRef.write(fullSnippetFile)
			    		snipRef.close()

			totalChars += newView.insert(edit, totalChars, '\n\nSnippet Consturction Complete. The following files are now available\n')
			for key, value in jsonDict.items():
				if(value['name'] != '.config'):
					totalChars += newView.insert(edit, totalChars, 'Snippet "' + value['name'] + '"  -> Triggered by keyword NC_"' + value['name'] + '"\n')

class SendnevercodeCommand(sublime_plugin.TextCommand, sublime_plugin.WindowCommand):
	def run(self, edit):
		self.edit = edit
		selText = [s for s in self.view.sel()]
		self.contents = self.view.substr(selText[0])
		self.view.window().show_input_panel('Please enter a name for the file', '', self.processShortcut, None, None)

	def processShortcut(self, text):
		self.fileName = text
		self.view.window().show_input_panel('Please enter a sublime shortcut word for the file', '', self.sendFile, None, None)

	def sendFile(self, text):
		self.shortcut =text;

		secretFile = open(os.path.join(dirName,'client_secret.txt'), 'r')
		secret = str(secretFile.read()).strip('\n')
		secretFile.close()

		headers = {'Allow-Control-Allow-Origin': '*', 'secret': secret}
		tokenResp = requests.get('http://localhost:3003/user/sublime-secret', headers=headers)
		token = str(tokenResp.text).strip('\n')
		
		if(token == 'Unauthorized'):
			sublime.message_dialog('Client Secret is not valid. Re-run setup')
		else:
			headers = {'Allow-Control-Allow-Origin': '*', 'authorization': token}
			data = {'fileName': self.fileName, 'shortcut': self.shortcut, 'contents': self.contents}
			snipResp = requests.post('http://localhost:3002/files/api/sublime-snippet', headers=headers, data=data)
			textResp = str(snipResp.text)
			if(textResp == 'snippet uploaded'):
				sublime.message_dialog('Snippet successfully uploaded')
			else:
				sublime.message_dialog('Snippet upload failed. Check server status')

class NevercodesecretCommand(sublime_plugin.TextCommand, sublime_plugin.WindowCommand):
	def run(self, edit):
		secretFile = open(os.path.join(dirName,'client_secret.txt'), 'r')
		secret = str(secretFile.read()).strip('\n')
		secretFile.close()

		self.view.window().show_input_panel('Please enter the new Client Secret', secret, self.processSecret, None, None)

	def processSecret(self, text):
		secret = text
		headers = {'Allow-Control-Allow-Origin': '*', 'secret': secret}
		tokenResp = requests.get('http://localhost:3003/user/sublime-secret', headers=headers)
		token = str(tokenResp.text).strip('\n')
		
		if(token == 'Unauthorized'):
			sublime.message_dialog('Client Secret is not valid. Re-run client secret setup and enter a new one')
		else:
			secretFile = open(os.path.join(dirName,'client_secret.txt'), 'w+')
			secretFile.write(secret)	
			secretFile.close
			sublime.message_dialog('New Client Secret was verified by the server. Saving new secret locally')

